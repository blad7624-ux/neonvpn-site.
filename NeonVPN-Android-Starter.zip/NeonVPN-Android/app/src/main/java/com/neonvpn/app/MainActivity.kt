package com.neonvpn.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080A12)
private val Panel = Color(0xFF121629)
private val Purple = Color(0xFFB45CFF)
private val Blue = Color(0xFF48C8FF)
private val Muted = Color(0xFF9CA3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NeonVpnApp() }
    }
}

private data class Server(val flag: String, val country: String, val city: String, val ping: String)

private val servers = listOf(
    Server("🇳🇱", "Netherlands", "Amsterdam", "18 ms"),
    Server("🇩🇪", "Germany", "Frankfurt", "24 ms"),
    Server("🇯🇵", "Japan", "Tokyo", "42 ms"),
    Server("🇺🇸", "United States", "New York", "86 ms")
)

@Composable
private fun NeonVpnApp() {
    var connected by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(servers.first()) }
    var showServers by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Purple,
            secondary = Blue, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF15102A), Bg, Color(0xFF080D1A)))
            )
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 22.dp, end = 22.dp, top = 34.dp, bottom = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, null, tint = Purple, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(9.dp))
                        Text("NEON", fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text(" VPN", fontSize = 25.sp, fontWeight = FontWeight.Light, color = Blue, letterSpacing = 1.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("YOUR CONNECTION. YOUR CONTROL.", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(38.dp))
                }

                item {
                    Box(
                        modifier = Modifier.size(224.dp)
                            .border(1.dp, Purple.copy(alpha = .42f), CircleShape)
                            .padding(13.dp)
                            .border(1.dp, Blue.copy(alpha = .28f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize()
                                .background(
                                    Brush.radialGradient(listOf(Color(0xFF38205C), Color(0xFF16182D), Bg)),
                                    CircleShape
                                )
                                .border(2.dp, Brush.linearGradient(listOf(Purple, Blue)), CircleShape)
                                .clickable { connected = !connected },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    if (connected) Icons.Default.CheckCircle else Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = if (connected) Blue else Purple,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(if (connected) "CONNECTED" else "CONNECT", fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Text(if (connected) "Demo state only" else "TAP TO START", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(22.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(if (connected) Blue else Purple, CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Text(if (connected) "Interface preview: connected" else "Ready to connect", color = if (connected) Blue else Muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(30.dp))
                }

                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("SERVER LOCATION", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                        Text("CHANGE  ↗", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { showServers = !showServers })
                    }
                    Spacer(Modifier.height(10.dp))
                    Surface(
                        color = Panel.copy(alpha = .94f),
                        shape = RoundedCornerShape(18.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30334C)),
                        modifier = Modifier.fillMaxWidth().clickable { showServers = !showServers }
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(selected.flag, fontSize = 30.sp)
                            Spacer(Modifier.width(13.dp))
                            Column(Modifier.weight(1f)) {
                                Text(selected.country, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                Text(selected.city, color = Muted, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(selected.ping, color = Blue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("sample ping", color = Muted, fontSize = 10.sp)
                            }
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.Default.Public, null, tint = Purple)
                        }
                    }
                    if (showServers) {
                        Spacer(Modifier.height(8.dp))
                        servers.forEach { server ->
                            Surface(
                                color = if (server == selected) Color(0xFF25203D) else Panel,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                                    .clickable { selected = server; showServers = false }
                            ) {
                                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(server.flag, fontSize = 24.sp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(server.country, fontWeight = FontWeight.Medium)
                                        Text(server.city, color = Muted, fontSize = 12.sp)
                                    }
                                    Text(server.ping, color = Blue, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        InfoTile("ENCRYPTION", "WireGuard-ready", Modifier.weight(1f))
                        InfoTile("PRIVACY", "No account UI", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "UI DEMO — no VPN tunnel is active. Connect a real WireGuard server before relying on this app.",
                        color = Color(0xFFFFC66D), fontSize = 11.sp, textAlign = TextAlign.Center, lineHeight = 16.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    Text("NEON VPN  •  CONCEPT BUILD 1.0", color = Color(0xFF686E88), fontSize = 10.sp, letterSpacing = 1.sp)
                }
            }
        }
    }
}

@Composable
private fun InfoTile(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Panel.copy(alpha = .8f),
        shape = RoundedCornerShape(15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF292D44))
    ) {
        Column(Modifier.padding(13.dp)) {
            Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
